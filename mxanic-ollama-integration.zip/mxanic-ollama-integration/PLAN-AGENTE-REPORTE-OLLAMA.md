# Plan: Agente de reporte con Ollama (qwen3-coder-next)

## Stack
- Ollama en local, modelo **qwen3-coder-next**
- BD: MySQL `mxanic-db` (usuario solo SELECT para el agente)
- App: CodeIgniter 4, nuevo modulo Agente de reporte

## Fases

### Fase 1: Config y cliente Ollama
- [x] 1.1 Config: URL Ollama (env), modelo, timeout → `app/Config/Ollama.php`, vars en `env`
- [x] 1.2 Library `OllamaClient`: HTTP a `/api/chat`, metodos `ask($userMessage)` y `chat($messages)` → `app/Libraries/OllamaClient.php`

### Fase 2: Seguridad SQL (solo SELECT)
- [x] 2.1 Library `SqlReadOnlyValidator`: una sentencia, empieza por SELECT, blacklist palabras, whitelist tablas (ordenes, ordenes_productos, etc.), LIMIT 500 por defecto → `app/Libraries/SqlReadOnlyValidator.php`
- [x] 2.2 Por ahora solo validacion estricta; opcional luego: usuario MySQL solo SELECT y grupo `agente_reportes` en Database.php

### Fase 3: Agente de reporte (NL -> SQL -> resultado -> NL)
- [x] 3.1 Schema para el LLM en ReporteAgent (tablas/columnas permitidas)
- [x] 3.2 Library `ReporteAgent`: generar SQL con Ollama, validar con SqlReadOnlyValidator, ejecutar con Database::connect(), respuesta NL con Ollama → `app/Libraries/ReporteAgent.php`
- [x] 3.3 Tabla `agente_reportes_log` + `AgenteReportesLogModel`; migracion `2025-02-05-000001_CreateAgenteReportesLog.php`. Ejecutar: `php spark migrate --all`

### Fase 4: API y UI
- [x] 4.1 Controller `AgenteReporte`: index(), ask() POST → `app/Controllers/AgenteReporte.php`
- [x] 4.2 Rutas GET /informes/agente-reporte, POST /informes/agente-reporte/ask (filtro auth:admin,user,externo)
- [x] 4.3 Vista + JS: `pages/shared/reporte/agente-reporte.php`, `assets/js/agente-reporte.js`; enlace en sidebar admin y externo

### Fase 5: Ajustes
- [ ] 5.1 Afinar prompts (qwen3-coder-next), ejemplos few-shot para SQL
- [ ] 5.2 LIMIT/timeout por defecto, manejo errores Ollama/DB

---

## Tunnel Cloudflare (Ollama local -> CapRover en VPS)

La app en CapRover necesita alcanzar Ollama en tu PC. Script en repo:

```bash
# En tu PC: instalar cloudflared una vez
brew install cloudflared

# Levantar Ollama y el tunel (dejar esta terminal abierta)
./scripts/tunnel-ollama.sh
```

Te muestra una URL tipo `https://xxx.trycloudflare.com`. Esa URL va en CapRover como **ollama_base_url** (Environment Variables). Si cerras y volves a ejecutar el script, la URL puede cambiar; actualiza la variable en CapRover.

---

## Orden de implementacion (paso a paso)
1. Config + OllamaClient + prueba manual
2. SqlReadOnlyValidator + prueba con SQLs de ejemplo
3. ReporteAgent (NL->SQL, validar, ejecutar, NL) + guardar en log
4. Controller + rutas + vista basica
