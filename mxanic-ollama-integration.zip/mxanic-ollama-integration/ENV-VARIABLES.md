# Variables de entorno – mxanic-dashboard

Lista de variables que usa la app. En CapRover: App Configs → Environment Variables. Para `.env` local usá el mismo nombre (en CI4 a veces se usa `app.baseURL` con punto o `app_baseURL` con guion bajo).

---

## Entorno y app (CodeIgniter)

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `CI_ENVIRONMENT` | development / production | `production` |
| `app.baseURL` | URL base del sitio (con barra final) | `https://tudominio.com/` |

---

## Base de datos

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `database.default.hostname` | Host MySQL | `localhost` o IP del servicio |
| `database.default.database` | Nombre de la BD | `mxanic-db` |
| `database.default.username` | Usuario MySQL | `root` |
| `database.default.password` | Contraseña MySQL | `***` |
| `database.default.DBDriver` | Driver | `MySQLi` |
| `database.default.port` | Puerto | `3306` |

---

## Seguridad / encriptación

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `encryption.key` | Clave para cifrado (CI4) | Base64 de 32 bytes |

---

## Ollama (Agente de reporte)

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `ollama_base_url` | URL de la API de Ollama | `https://xxx.trycloudflare.com` |
| `ollama_model` | Modelo a usar | `qwen3-coder-next` |
| `ollama_timeout` | Timeout en segundos | `60` |

---

## WooCommerce (webhooks / API)

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `woo_commerce_webhook_secret` | Secret del webhook WC | `***` |
| `woo_commerce_url` | URL de la tienda WC | `https://tienda.com` |
| `woo_commerce_consumer_key` | Consumer key API WC | `ck_***` |
| `woo_commerce_consumer_secret` | Consumer secret API WC | `cs_***` |
| `same_day_shipping_notification_emails` | Emails notificación envío mismo día | `a@mail.com,b@mail.com` |

---

## TrueDesk

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `truedesk_url` | URL API TrueDesk | `https://api.truedesk.com` |
| `truedesk_access_token` | Token de acceso | `***` |
| `truedesk_owner` | Owner | `***` |
| `truedesk_group` | Group | `***` |
| `truedesk_type` | Type | `***` |
| `truedesk_priority` | Priority | `***` |

---

## Orden / facturación / personalizables

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `facturacion_url` | URL del servicio de facturación | `https://...` |
| `costo_etiqueta` | Costo etiqueta (personalizables) | `10.00` |
| `costo_flor_natural` | Costo flor natural | `***` |
| `costo_texto_sobre_caja` | Costo texto sobre caja | `***` |

---

## GML / envíos

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `gvqr_url` | URL GVQR (GMLEnvios) | `https://...` |

---

## Email

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `email_from` | Dirección remitente | `noreply@tudominio.com` |
| `email_from_title` | Nombre del remitente | `GeekMerch` |

---

## API (auth JWT / idioma)

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `jwt_secret` | Secret para JWT | `***` |
| `lang` | Código de idioma por defecto | `es` |

---

## Opcionales (desarrollo / seeds)

| Variable | Uso | Ejemplo |
|----------|-----|---------|
| `SEED_ORDER_COUNT` | Cantidad de órdenes al hacer seed | `10` |
| `CODEIGNITER_SCREAM_DEPRECATIONS` | Ver deprecations (debug) | `1` |
